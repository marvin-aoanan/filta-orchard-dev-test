<?php
wp_nav_menu(array(
    'theme_location' => 'primary-menu',
    'menu_class'      => 'navbar menu menu-icon',
));

?>